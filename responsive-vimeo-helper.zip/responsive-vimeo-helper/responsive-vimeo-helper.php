<?php

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

/*
Plugin Name: Responsive Vimeo Helper
Description: Add code to make embedded Vimeo sourced videos responsive and add a thumbnail overlay/play button.
Version: 1.1.0
Author: Alex Patton
*/

require_once('php/rvh_functions.php');

$rvhFunc = new rvh_functions();